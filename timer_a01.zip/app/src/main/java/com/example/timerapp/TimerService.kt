package com.example.timerapp

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat

class TimerService : Service() {
    private var timer: CountDownTimer? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 인텐트로부터 타이머 시간(밀리초)을 받아옴
        val duration = intent?.getLongExtra("duration", 0L) ?: 0L
        Log.d("TimerService", "받은 타이머 시간: $duration ms")

        // 유효하지 않은 시간이라면 서비스 중지
        if (duration <= 0L) {
            stopSelf()
            return START_NOT_STICKY
        }

        // 포그라운드 서비스 시작 (알림 표시)
        startForegroundServiceNotification()

        // CountDownTimer 시작
        timer = object : CountDownTimer(duration, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                Log.d("TimerService", "남은 시간: $millisUntilFinished ms")
            }

            override fun onFinish() {
                Log.d("TimerService", "타이머 완료!")
                showTimerDonePopup() // ✅ 타이머 완료 팝업 액티비티 실행
                stopSelf() // 서비스 종료
            }
        }.start()

        return START_NOT_STICKY
    }

    // 포그라운드 서비스를 위한 알림 생성 및 시작
    private fun startForegroundServiceNotification() {
        val channelId = "timer_channel"
        val channelName = "Timer Notification"

        // Android 8.0 이상은 알림 채널 필요
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_LOW)
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(chan)
        }

        // 알림 설정
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("타이머 실행 중")
            .setContentText("요리 타이머가 작동 중입니다.")
            .setSmallIcon(R.drawable.ic_timer)
            .build()

        // 포그라운드 서비스 시작
        startForeground(1, notification)
    }

    // ✅ 타이머 완료 시 팝업 액티비티 실행
    private fun showTimerDonePopup() {
        val popupIntent = Intent(this, TimerDoneActivity::class.java)

        // 새 작업으로 액티비티 실행하고 백스택 초기화
        popupIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)

        // PendingIntent로 팝업을 실행 (FLAG_IMMUTABLE 필수)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            popupIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // PendingIntent 실행 시도
        try {
            pendingIntent.send()
        } catch (e: PendingIntent.CanceledException) {
            e.printStackTrace()
        }
    }

    // 서비스 종료 시 타이머 취소
    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
