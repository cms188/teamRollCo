package com.example.timerapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class RecipeListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe_list) // XML 레이아웃 존재해야 함

        val backBtn = findViewById<Button>(R.id.returnmain)

        backBtn.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            // 이전 액티비티들 다 없애고 MainActivity를 맨 위로 올림
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish() // 현재 액티비티 종료
        }
    }
}
