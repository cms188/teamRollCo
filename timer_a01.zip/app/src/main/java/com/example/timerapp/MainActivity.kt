//package kr.ac.yuhan.cs.timer_a01
package com.example.timerapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val timeInput = findViewById<EditText>(R.id.timeInput)
        val startBtn = findViewById<Button>(R.id.startButton)
        // 추가된 레시피 리스트 버튼
        val recipeBtn = findViewById<Button>(R.id.recipeButton)

        startBtn.setOnClickListener {
            val secondsStr = timeInput.text.toString()
            val seconds = secondsStr.toLongOrNull()
            if (seconds != null && seconds > 0) {
                val intent = Intent(this, TimerService::class.java)
                intent.putExtra("duration", seconds * 1000L)
                ContextCompat.startForegroundService(this, intent)
            } else {
                Toast.makeText(this, "올바른 시간을 입력하세요 (초 단위)", Toast.LENGTH_SHORT).show()
            }
        }
        // 클릭 시 RecipeListActivity로 이동
        recipeBtn.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}