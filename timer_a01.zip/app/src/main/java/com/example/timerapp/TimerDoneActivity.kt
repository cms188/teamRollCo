//package kr.ac.yuhan.cs.timer_a01

package com.example.timerapp

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class TimerDoneActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        AlertDialog.Builder(this)
            .setTitle("⏰ 타이머 종료")
            .setMessage("요리 타이머가 완료되었습니다!")
            .setPositiveButton("확인") { dialog, _ ->
                dialog.dismiss()
                finish()
            }
            .setCancelable(false)
            .show()
    }
}
