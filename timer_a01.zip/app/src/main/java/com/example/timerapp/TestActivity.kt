package com.example.timerapp

import androidx.appcompat.app.AppCompatActivity

class TestActivity : AppCompatActivity(){
}